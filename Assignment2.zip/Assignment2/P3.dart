void main() {
  for (int i = 100; i <= 109; i++) {
    print(i);
  }
}
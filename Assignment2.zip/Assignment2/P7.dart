void main() {
  for (int i = 1; i <= 10; i++) {
    int ans = 12 * i;
    print("12 x $i = $ans");
  }
}
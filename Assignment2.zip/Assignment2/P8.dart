void main() {
  for (int i = 10; i >= 1; i--) {
    int ans = 12 * i;
    print("12 x $i = $ans");
  }
}
void main() {
  int i = 1;
  while (i <= 10) {
    int result = 2 * i;
    print("2 x $i = $result");
    i++;
  }
}
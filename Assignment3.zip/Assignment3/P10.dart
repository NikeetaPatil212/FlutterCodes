void main() {
  int number = 6;
  int factorial = 1;
  int num = number;

  while (number > 0) {
    factorial *= number;
    number--;
  }

  print("The factorial of $num is $factorial");
}
void main() {
  int i = 10;
  while (i >= 1) {
    int result = 5 * i;
    print("5 x $i = $result");
    i--;
  }
}
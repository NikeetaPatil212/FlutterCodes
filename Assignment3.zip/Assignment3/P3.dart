void main() {
  int i = 9;
  while (i >= 1) {
    print(i);
    i--;
  }
}
void main() {
  int num = 40;

  while (num <= 50) {
    if (num % 2 != 0) {
      int square = num * num;
      print("Square of $num is $square");
    } else {
      int cube = num * num * num;
      print("Cube of $num is $cube");
    }
    num++;
  }
}

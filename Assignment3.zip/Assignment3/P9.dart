void main() {
  int daysRemaining = 7; 

  while (daysRemaining > 0) {
    print("$daysRemaining days remaining");
    daysRemaining--;
  }
 print("Assignment Overdue.");
}